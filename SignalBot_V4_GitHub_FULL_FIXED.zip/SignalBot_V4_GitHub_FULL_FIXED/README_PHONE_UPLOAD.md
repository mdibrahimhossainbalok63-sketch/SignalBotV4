# SignalBot V4 — Phone/GitHub APK Build

IMPORTANT: This ZIP contains the **entire Android project**, not only the GitHub Actions workflow.

## Phone-only setup
1. Open your GitHub repository.
2. Upload **all files and folders inside this ZIP** to the repository root.
3. Make sure these exist at the repository root:
   - `settings.gradle.kts`
   - `build.gradle.kts`
   - `gradle.properties`
   - `app/build.gradle.kts`
   - `app/src/main/AndroidManifest.xml`
   - `app/src/main/java/...`
   - `.github/workflows/build-apk.yml`
4. Do not put the project inside an extra folder such as `SignalBot_V4_GitHub_FULL_FIXED/`.
5. Commit to `main`.
6. Open **Actions → Build SignalBot V4 APK**.
7. When it finishes successfully, open the run → **Artifacts** → `SignalBot-V4-debug-APK`.

The workflow intentionally uses Gradle 8.9 directly, so a Gradle wrapper JAR is not required.

## Current app limitation
The app is a V4 signal/paper-trading prototype. Quotex real-money execution is disabled until an official, documented Quotex trading API is available.
